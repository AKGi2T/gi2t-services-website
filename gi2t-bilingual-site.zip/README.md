# GI2T & Services – Bilingual Static Site (EN/FR)

This repository contains a **static, bilingual website** ready for Netlify deployment.

## Structure
- `/index.html` → language chooser
- `/en/*` → English pages (home, about, services, clients, contact, thank-you)
- `/fr/*` → French pages (accueil, a-propos, services, references, contact, merci)
- `/css/style.css` → shared styles
- `/js/script.js` → shared scripts
- `/assets/*` → images, logo, PDF

## Netlify Forms
Forms are set up with:
```html
<form name="contact-en" method="POST" data-netlify="true" netlify-honeypot="bot-field" action="/en/thank-you.html">
  <input type="hidden" name="form-name" value="contact-en">
  <div data-netlify-recaptcha="true"></div>
</form>
```
> In Netlify dashboard → **Forms** → enable email notifications to: **abdoukarim028@gmail.com**

## Domain & SEO
- Update `sitemap.xml` and `robots.txt` if your domain is not `https://gittservices.com`.
- Each page includes basic meta tags (title, description, OG).

## Company Profile PDF
Place your PDF at: `/assets/GI2T-Company-Profile.pdf`. The download buttons will work automatically.

## Colors
- Green `#2F8F46` (primary), Dark Gray `#2B2B2B`

## License
All content © GI2T & Services.
